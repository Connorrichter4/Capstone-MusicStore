package com.hcl.capstone.repositories;

import org.springframework.data.repository.CrudRepository;

import com.hcl.capstone.entities.Role;

public interface RoleRepository extends CrudRepository<Role, Long>{
	
}
